---
name: use-internet
description: 🔍 当问题需要联网、英文深度搜索或最新资料时使用。优先调用 MCP 与官方文档，再补充网页搜索。
---

# Use Internet

在以下情况触发：
- 用户明确要求联网搜索。
- 问题需要最新信息、外部文档或英文深度搜索。

执行要求：
1. 优先使用英文检索相关资料。
2. 若存在 MCP，优先使用合适的 MCP：
   - 技术文档：`Context7`
   - Microsoft 技术：`microsoft-docs-mcp`
   - 网页搜索：`DuckDuckGo`
   - GitHub 文档：`DeepWiki`
3. 对技术问题优先看官方文档、主仓库与一手资料。
4. 若问题带有时效性，必须显式校验最新信息，不要凭旧记忆回答。
5. 输出时给出来源与结论，不要只给模糊总结。
