---
name: pro-summary
description: 💼 当用户需要总结当前工作、沉淀长期记忆或执行“总结归档 / Archive Context / Compress History”时使用。按 .ai_memory 四文件协议写入状态、真相与思维演变。
---

# Pro Summary

在以下情况触发：
- 用户希望把当前工作完整归档，方便后续继续。
- 用户希望总结当前进展、下一步、偏好规则或长期记忆。
- 用户明确说出 `Archive Context`、`Compress History` 或“总结归档”。

执行要求：
1. 先汇总当前阶段已经完成的工作、关键决策、未解决问题和下一步建议。
2. 优先检查项目根目录的 `.ai_memory/`；若不存在则创建，并按以下固定协议维护四个文件：
   - `1_project_context.md`
     - Mode: Read-Mostly
     - 用途: 项目核心知识库，保存已确认的 System prompts、最终代码模式、核心共识、Single Source of Truth（唯一真相源）
     - 触发: 只要形成新的“Truth（稳定事实/最终共识）”就更新
   - `2_active_task.md`
     - Mode: Snapshot / Overwrite
     - 用途: 当前任务状态、立即下一步、最新阻断
     - 触发: 每次总结时都覆盖为最新快照
   - `3_work_log.md`
     - Mode: Append-Only
     - 用途: 日常开发流水账，记录当天的简短变更日志
   - `0_archive_context.md`
     - Mode: Append-Only（按块追加）
     - 用途: 记录思维演变路径、为什么改变方向、关键取舍与上下文压缩
     - 读取规则: 开启新会话时优先读取最后一个归档块
3. `.ai_memory` 内建议遵循以下模板意图：
   - `1_project_context.md`: 项目目标、核心共识、最终确定的规则与模式
   - `2_active_task.md`: 当前任务状态、待办、下一步动作
   - `3_work_log.md`: 开发流水账
   - `0_archive_context.md`: 归档日期、核心议题背景、关键思维演变路径、下一步行动指引
4. 若只是常规总结：
   - 必须更新 `2_active_task.md`
   - 若有新的稳定事实，更新 `1_project_context.md`
   - 若本次工作值得留痕，向 `3_work_log.md` 追加简报
5. 若触发词为 `Archive Context`、`Compress History` 或“总结归档”，必须执行完整归档工作流：
   1. Review 整个会话历史
   2. 提取新的系统规则、代码模式、最终决策，并更新 `1_project_context.md`
   3. 构建 “Cognitive Evolution Path（思维演变路径）”，将深度复盘追加到 `0_archive_context.md`
   4. 用最新状态覆盖 `2_active_task.md`
   5. 如有必要，向 `3_work_log.md` 追加简短归档记录
   6. 最终向用户输出：
      `核心知识已更新至 project_context，思维路径已归档至 0_archive_context。您可以放心清理对话历史。`
6. 同时检查当前工作区的用户提示和偏好指令。
7. 若存在稳定规则，则存放到 `.agent/rules/指令名.md`。
8. 创建前必须先检查 `.agent/rules/` 中已有文档，遇到同类规则要合并更新，而不是重复创建。
9. 若没有额外稳定规则，不要为了凑数而生成空规则文件。
